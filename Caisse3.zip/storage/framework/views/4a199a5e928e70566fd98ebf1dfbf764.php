
    <?php $__env->startSection('content'); ?>
                        <!--/ Hoverable Table rows -->
                        <?php if(Auth::user()->point_vente): ?>
                            <div class="d-flex justify-content-start">
                                <h5 class="pb-1 mb-4" style="margin-right: 20px;">Point vente</h5>
                                <h5 class="pb-1 mb-4 text-primary"><i class="menu-icon tf-icons fa-solid fa-cash-register"></i><?php echo e(Auth::user()->point_vente->nom_point_vente); ?></h5>
                                                
                            </div>
                            
                            <div class="row mb-5">
                                <div class="col-md-4 col-lg-3">
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <div class="row">
                                                
                                                <div class="col-7">
                                                    <h6 class="card-title"><?php echo e($recap_etat_journalier['date']); ?></h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-5">
                                                    <p class="card-text">Tickets</p>
                                                </div>
                                                <div class="col-7 text-right" style="text-align: right;">
                                                    <h6 class="card-title badge bg-success "><?php echo e($recap_etat_journalier['nombre_ticket']); ?></h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-5">
                                                    <p class="card-text">Solde</p>
                                                </div>
                                                <div class="col-7 text-right" style="text-align: right;">
                                                    <h6 class="card-title badge bg-success"><?php echo e($recap_etat_journalier['somme_total']); ?> FCFA</h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-5">
                                                    <p class="card-text">Gérant</p>
                                                </div>
                                                <div class="col-7 text-right" style="text-align: right;">
                                                    <p class="card-title" style="font-weight: bold;"><?php echo e($point_vente->gerant); ?></p>
                                                </div>
                                            </div>
                                            <?php if($recap_etat_journalier['nombre_ticket']): ?>
                                                <a href="<?php echo e(route('espace_caisse')); ?>"  class="btn btn-primary">Continuer</a>
                                            <?php endif; ?>
                                            <?php if(!$recap_etat_journalier['nombre_ticket']): ?>
                                                <a href="<?php echo e(route('espace_caisse')); ?>"  class="btn btn-primary">Commencer</a>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="card p-3">
                                        <h5 class="card-header">Etat journalier</h5>
                                        <div class="table-responsive text-nowrap">
                                            <table class="table table-hover " id="myTable">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Tickets vendu</th>
                                                        <th>Montant total</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-border-bottom-0 ">
                                                    <?php
                                                        $total_montant = 0;
                                                        $nombre_total = 0;
                                                    ?>
                                                <?php $__currentLoopData = $users_grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="cursor-pointer">
                                                        <td>
                                                            <i class="fa-solid fa-calendar fa-lg text-danger me-3"></i>
                                                            <span class="fw-medium"><?php echo e($date_group->first()->created_at->format('d-m-Y')); ?></span>
                                                        </td>
                                                        <?php
                                                            $total = 0;
                                                            $nombre = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $date_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $total += $etat->montant_total;
                                                                $nombre ++;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <td><?php echo e($nombre); ?></td>
                                                        <td><?php echo e($total); ?> FCFA</td>
                                                        
                                                    </tr>
                                                    <?php
                                                        $total_montant += $total;
                                                        $nombre_total += $nombre;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <tfoot style="" class="table-dark">
                                                    <tr>
                                                        <th class="text-white">Total</th>
                                                        <th class="text-white"><?php echo e($nombre_total); ?></th>
                                                        <th class="text-white"><?php echo e($total_montant); ?> FCFA</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-cash-register fa-xl"></i>    
                                <strong>Point de vente non disponible</strong> 
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> 
                        <?php endif; ?>
           
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CaisseManagement\resources\views/point_ventes/caisse.blade.php ENDPATH**/ ?>