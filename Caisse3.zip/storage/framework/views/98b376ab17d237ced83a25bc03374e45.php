
    <?php $__env->startSection('content'); ?>
        <div class="card p-2">
                <div class="m-2" >
                    <a href="<?php echo e(route('espace_caisse')); ?>" class="btn btn-primary"><i class="fa-solid fa-rotate-left fa-lg text-white me-3"></i>Quitter</a>
                </div>
                <h5 class="card-header">Liste des tickets de la caisse</h5>
                    <div class="table-responsive text-nowrap">
                        <table class="table table-hover" id="myTable">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Numero</th>
                                    <th>Consultation</th>
                                    <th>Client</th>
                                    <th>IPM</th>
                                    <th>Taux IPM %</th>
                                    <th>Type paiement</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php $__currentLoopData = $caisses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caisse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="clickable-row" data-target="_blank" data-href="<?php echo e(route('get_print_ticket', ['slug'=>$caisse->ticket->id])); ?>" style="cursor:pointer;">
                                        <td>
                                            <i class="fa-solid fa-ticket fa-lg text-success me-3"></i>
                                            <span class="fw-medium"><?php echo e($caisse->ticket->created_at->format('d-m-Y H:i:s')); ?></span>
                                        </td>
                                        <td><?php echo e($caisse->ticket->numero); ?></td>
                                        <td><span class="badge bg-label-primary me-1"><?php echo e($caisse->ticket->consultation->nom_consultation); ?></span></td>
                                        <td><span class=""></span><?php echo e($caisse->ticket->client->prenom_client); ?> <?php echo e($caisse->ticket->client->nom_client); ?></td>
                                        <td><span class=""><?php echo e($caisse->ticket->client->ipm->nom_ipm ?? "--"); ?></span></td>
                                        <td><span class=""><?php echo e($caisse->ticket->client->taux_pourcentage ?? "--"); ?></span></td>
                                        <td><?php echo e($caisse->ticket->type_paiement); ?></td>
                                        <td><?php echo e($caisse->ticket->montant_total); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot style="" class="table-dark">
                                <tr>
                                    <th class="text-white text-left" style="text-align: left !important;" colspan="4">Nombre de tickets : <?php echo e($caisses->count()); ?></th>
                                    <th class="text-white text-right" style="text-align: right !important;" colspan="4">Total : <?php echo e($caisses->sum('solde_ticket')); ?> FCFA</th>
                                    
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CaisseManagement\resources\views/tickets/list_all_tickets_caisse.blade.php ENDPATH**/ ?>