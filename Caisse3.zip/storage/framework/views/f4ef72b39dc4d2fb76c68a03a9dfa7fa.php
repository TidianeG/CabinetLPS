
    <?php $__env->startSection('content'); ?>
                
                <div class="mb-3 mt-3">
                    <form action="<?php echo e(route('get_all_tickets_etat_financier')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3 align-items-center justify-content-end">
                            <div class="col-auto">
                                <label for="inputPassword6" class="col-form-label">Faire un état des : </label>
                            </div>
                            <div class="col-auto">
                                <select name="etat_select" id="etat_select" class="form-control" required>
                                    <option value="ticket">Tickets</option>
                                    <option value="consultation">Consultation</option>
                                </select>
                            </div>
                            <div class="col-auto" id="all_consultation" hidden>
                                <select name="consultation_select" id="consultation_select" class="form-control">
                                    <option value="all">Toutes</option>
                                    <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($consultation->id); ?>"><?php echo e($consultation->nom_consultation); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-auto">
                                <label for="inputPassword6" class="col-form-label">Du : </label>
                            </div>
                            <div class="col-auto">
                                <input type="date" id="date_debut" name="date_debut" required class="form-control" aria-describedby="passwordHelpInline">
                            </div>
                            <div class="col-auto">
                                <label for="inputPassword6" class="col-form-label">Au : </label>
                            </div>
                            <div class="col-auto">
                                <input type="date" id="date_fin" name="date_fin" class="form-control" aria-describedby="passwordHelpInline">
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary">Valider</button>
                            </div>
                        </div>
                    </form>
                </div>
                    <!-- Hoverable Table rows -->
                <div class="card p-2">
                    <h5 class="card-header">Liste des Tickets</h5>
                    <div class="table-responsive text-nowrap">
                        <table class="table table-hover" id="myTable">
                            <thead>
                                <tr>
                                    <th>Numero</th>
                                    <th>Date</th>
                                    <th>Consultation</th>
                                    <th>Client</th>
                                    <th>Caissier(e)</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="clickable-row" data-target="_blank" data-href="<?php echo e(route('get_print_ticket', ['slug'=>$ticket->id])); ?>" style="cursor:pointer;">
                                        <td>
                                            <i class="fa-solid fa-ticket fa-lg text-success me-3"></i>
                                            <span class="fw-medium"><?php echo e($ticket->numero); ?></span>
                                        </td>
                                        <td><?php echo e($ticket->created_at->format('d-m-Y H:i:s')); ?></td>
                                        <td><?php echo e($ticket->consultation->nom_consultation); ?></td>
                                        <td><span class="badge bg-label-primary me-1"><?php echo e($ticket->client->prenom_client); ?> <?php echo e($ticket->client->nom_client); ?></span></td>
                                        <td><span class="badge bg-label-primary me-1"><?php echo e($ticket->user->prenom); ?> <?php echo e($ticket->user->nom); ?></span></td>
                                        <td><span class="badge bg-label-primary me-1"><?php echo e($ticket->montant_total); ?> FCFA</span></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot style="" class="table-dark">
                                <tr>
                                    <th class="text-white text-left" style="text-align: left;" colspan="3">Nombre de tickets : <?php echo e($tickets->count()); ?></th>
                                    <th class="text-white text-right" style="text-align: right !important;" colspan="3">Total : <?php echo e($tickets->sum('montant_total')); ?> FCFA</th>
                                    
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <!--/ Hoverable Table rows -->

                <script>
                    document.getElementById('etat_select').addEventListener('change', function(){
                        if (document.getElementById('etat_select').value=='consultation') {
                            document.getElementById('all_consultation').hidden=false;
                        }
                        else{
                            document.getElementById('all_consultation').hidden=true;
                        }
                    })
                </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\CaisseManagement\resources\views/tickets/lists_des_tickets.blade.php ENDPATH**/ ?>